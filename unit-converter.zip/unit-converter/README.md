# Python Unit Converter

Offline unit conversion for length, mass, time, area, volume, speed,
temperature, energy, pressure, and data storage. No external packages needed.

## Run

Install Python 3.10 or newer. Open a terminal in this folder:

```console
python unit_converter.py
python unit_converter.py convert 100 C F
python unit_converter.py convert 1 mi km
python unit_converter.py units
python unit_converter.py table 1 L
python unit_converter.py search gallon
python unit_converter.py batch examples/input.csv batch_results.csv
python -m unittest -v
```

On Windows, use `py` instead of `python` if that is your Python launcher.
The batch example deliberately includes invalid rows; exit code 1 indicates
row errors, and the output CSV explains each error. General input/file errors
return 2; success returns 0. Add `--overwrite` to replace a batch output file.

## Features

- Interactive numbered menu with repeated conversions and graceful exit.
- Unit names, aliases, scientific notation, and conversion tables.
- Explicit US liquid/imperial units and decimal/binary storage units.
- JSON history import/export, CSV batch processing, configurable precision.
- Invalid-number, incompatible-category, overflow, and absolute-zero checks.
- Automated regression tests and a GitHub Actions test workflow.

Unit names ignore capitalization. Use `byte` and `bit` explicitly; `B` and `b`
are deliberately unsupported to avoid ambiguous case-insensitive lookup.
Numbers may include a decimal point or exponent, but not thousands separators.
Negative values are accepted outside temperature because some applications use
signed measurements; this program does not validate every physical context.
Temperature is absolute temperature, not a temperature difference.

## Design

`Unit` stores a scale and offset. Conversion follows:

```text
base = input * source.factor + source.offset
output = (base - target.offset) / target.factor
```

Base units are meter, kilogram, second, square meter, liter, meter per second,
kelvin, joule, pascal, and byte. Ordinary units have zero offset. Using one base
per category avoids maintaining a separate formula for every pair of units.

`UnitRegistry` owns units and aliases; `Converter` validates and calculates;
`Conversion` stores results; `History` manages session records; `Menu` handles
interaction. CLI parsing and CSV handling reuse the same conversion engine.
History loading recalculates results and resets timestamps to the import time.
It replaces the current list only after all imported records validate.

## Assignment support

- `docs/REPORT_GUIDE.md`: report content and the rubric mapping.
- `docs/PRESENTATION.md`: slide outline, timing, and recording checklist.
- `examples/input.csv`: successful and invalid batch inputs.
- `test_converter.py`: behavior tests, separate from the application code.

The application itself exceeds 400 nonblank, noncomment lines; test code and
documentation are additional. This is AI-generated starter work. The rubric
says the group must write the code: confirm your course's AI rules, understand
and adapt the implementation, and accurately describe each person's work.
Do not claim this generated code was independently written by your group.

Repository: https://github.com/spencerortyl-prog/Unit-Convert

## References

Reference materials for checking conversion definitions and Python concepts:

- NIST SI conversion tables: https://www.nist.gov/pml/special-publication-811/nist-guide-si-appendix-b-conversion-factors
- BIPM SI Brochure: https://www.bipm.org/en/publications/si-brochure
- Python standard library: https://docs.python.org/3/library/
- Python classes: https://docs.python.org/3/tutorial/classes.html
- Python errors: https://docs.python.org/3/tutorial/errors.html

No third-party source code or runtime packages are included. Floating-point
rounding applies; displayed precision does not change internal calculations.
