"""Behavioral tests; run python -m unittest -v."""
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from unit_converter import (
    ConversionError, Converter, History, Menu, batch_convert, build_registry, main,
)


class ConverterTests(unittest.TestCase):
    def setUp(self):
        self.converter = Converter(build_registry())

    def test_known_values(self):
        cases = [
            (1, 'mi', 'km', 1.609344),
            (1, 'lb', 'g', 453.59237),
            (2, 'h', 'min', 120),
            (1, 'acre', 'm2', 4046.8564224),
            (1, 'gal_us', 'L', 3.785411784),
            (1, 'gal_imp', 'L', 4.54609),
            (36, 'km/h', 'm/s', 10),
            (32, 'F', 'C', 0),
            (100, 'C', 'F', 212),
            (-273.15, 'C', 'K', 0),
            (1, 'kWh', 'J', 3600000),
            (1, 'atm', 'Pa', 101325),
            (1, 'MiB', 'byte', 1048576),
            (1, 'MB', 'byte', 1000000),
            (8, 'bit', 'byte', 1),
        ]
        for value, source, target, expected in cases:
            with self.subTest(source=source, target=target):
                result = self.converter.convert(value, source, target).result
                self.assertAlmostEqual(result, expected, places=8)

    def test_every_unit_round_trip(self):
        registry = self.converter.registry
        for category in registry.categories():
            units = registry.in_category(category)
            for source in units:
                for target in units:
                    with self.subTest(source=source.symbol, target=target.symbol):
                        first = self.converter.convert(300, source.symbol, target.symbol)
                        back = self.converter.convert(first.result, target.symbol, source.symbol)
                        self.assertAlmostEqual(back.result, 300, places=8)

    def test_invalid_inputs(self):
        cases = [
            ('abc', 'm', 'km'), ('nan', 'm', 'km'),
            ('inf', 'm', 'km'), ('1e999', 'm', 'km'),
            (1, 'unknown', 'm'), (1, 'm', 'kg'),
            (-1, 'K', 'C'), (-274, 'C', 'F'),
            (1e308, 'km', 'm'),
        ]
        for value, source, target in cases:
            with self.subTest(value=value, source=source):
                with self.assertRaises(ConversionError):
                    self.converter.convert(value, source, target)

    def test_alias_and_scientific_notation(self):
        result = self.converter.convert('1e3', ' METERS ', 'km')
        self.assertEqual(result.result, 1)

    def test_table_and_search(self):
        records = self.converter.table(1, 'm')
        self.assertEqual(len(records), 10)
        self.assertTrue(all(record.category == 'length' for record in records))
        self.assertTrue(self.converter.registry.search('gallon'))

    def test_history_round_trip_and_atomic_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'history.json'
            history = History()
            history.add(self.converter.convert(1, 'mi', 'km'))
            history.save(path)
            restored = History()
            restored.load(path, self.converter)
            self.assertEqual(restored.records[0].result, 1.609344)
            path.write_text('[{"value": 1}]', encoding='utf-8')
            with self.assertRaises(ConversionError):
                restored.load(path, self.converter)
            self.assertEqual(len(restored.records), 1)
            history.clear()
            self.assertEqual(history.records, [])

    def test_history_recomputes_untrusted_result(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'history.json'
            path.write_text(json.dumps([
                dict(value=1, source='m', target='cm', result=999)
            ]), encoding='utf-8')
            history = History()
            history.load(path, self.converter)
            self.assertEqual(history.records[0].result, 100)

    def test_batch_preserves_errors(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / 'in.csv'
            target = Path(directory) / 'out.csv'
            source.write_text('value,source,target\n1,m,cm\n1,m,kg\nabc,m,cm\n', encoding='utf-8')
            self.assertEqual(batch_convert(self.converter, source, target), (1, 2))
            self.assertIn('error', target.read_text(encoding='utf-8'))
            with self.assertRaises(ConversionError):
                batch_convert(self.converter, source, source)

    def test_bad_csv_header(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / 'in.csv'
            source.write_text('wrong,columns\n1,2\n', encoding='utf-8')
            with self.assertRaises(ConversionError):
                batch_convert(self.converter, source, Path(directory) / 'out.csv')

    def test_cli_success_and_failure(self):
        with contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(main(['convert', '100', 'C', 'F']), 0)
        self.assertIn('212 F', output.getvalue())
        with contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(main(['convert', '1', 'm', 'kg']), 2)

    def test_menu_recovers_after_error(self):
        responses = ['invalid', '1', 'bad', 'm', 'cm', '1', '2', 'm', 'cm', '4', '0']
        with patch('builtins.input', side_effect=responses):
            with contextlib.redirect_stdout(io.StringIO()) as output:
                Menu(self.converter).run()
        self.assertIn('Error:', output.getvalue())
        self.assertIn('2 m = 200 cm', output.getvalue())
        self.assertIn('Goodbye!', output.getvalue())


if __name__ == '__main__':
    unittest.main()
