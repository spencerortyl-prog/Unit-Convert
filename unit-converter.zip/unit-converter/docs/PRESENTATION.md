# Presentation and demonstration plan

Target: approximately ten minutes for an individual or two-person group,
followed by about two minutes of questions. For other group sizes, follow the
instructor's approximately five minutes per student instruction.

| Slide | Content | Time |
| --- | --- | --- |
| 1 | Unit Converter; your actual names and class | 0:20 |
| 2 | Project goals and Python 3.10+ software requirements | 0:40 |
| 3 | Introduction, your motivation, manual conversion and improvements | 1:00 |
| 4 | Flow diagram from REPORT_GUIDE.md and scale/offset algorithm | 1:10 |
| 5 | Classes, data structures, loops, functions, exceptions | 1:10 |
| 6 | Successful length, temperature, volume, data conversions | 1:30 |
| 7 | Invalid inputs, category mismatch, absolute-zero checks | 1:00 |
| 8 | History export/import and mixed-validity CSV batch | 1:10 |
| 9 | Test results, limitations, future improvements, conclusion | 1:20 |
| 10 | References and GitHub source/documentation link | 0:40 |

## Recording and screenshot checklist

Create actual screenshots or a narrated screen recording before class. Keep
the recording and screenshots locally as backups for the live demonstration.

1. Launch `python unit_converter.py` and explain the menu.
2. Convert 1 mi to km and 100 C to F.
3. Compare 1 gal_us and 1 gal_imp to liters.
4. Compare 1 MB and 1 MiB to bytes.
5. Demonstrate an invalid number, incompatible categories, and -1 K.
6. Show the program recovering and accepting another valid conversion.
7. Save history to a JSON file, clear it, and reload it.
8. Run the CSV example and explain both successful and error rows.
9. Run `python -m unittest -v` and explain what testing proves.
10. Show the public repository and explain genuine team contributions.

This is a planning document; no presentation file or screen recording is
represented as already created. Insert screenshots into your actual slides.

## Questions to rehearse

- Why use a shared base unit? Fewer formulas and a consistent validation path.
- Why does temperature need an offset? Celsius and Fahrenheit have shifted zeros.
- Why separate MB and MiB? Decimal and binary prefixes use different factors.
- What happens on invalid input? The interface explains the error and recovers.
- Can users convert mass to volume? No; that requires material density.
- What would you improve? Precision choices, GUI accessibility, and custom units.
- What did each member implement? Answer using actual work and Git history.

Final slide repository: https://github.com/spencerortyl-prog/Unit-Convert
