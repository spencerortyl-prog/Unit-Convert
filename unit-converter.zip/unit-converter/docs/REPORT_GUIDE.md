# Unit converter project report guide

Prepare the final Word report in Times New Roman, 12 point. Insert your actual
group number, names, class name, and subject code on its cover. This Markdown
file supplies technical content; it is not the final formatted report.

## Contents and abstract

The program converts measurements across ten categories through an interactive
menu, terminal commands, and CSV files. A shared conversion engine validates
inputs and applies scale and offset formulas. Session history can be exported
to JSON and imported with recalculation. Automated tests cover known results,
unit round trips, error handling, file operations, and menu recovery.

## Goal and software requirements

Provide repeatable offline conversions and clear error messages while showing
Python data structures, functions, loops, exception handling, and classes.
Requirements: Python 3.10+, a terminal, and any operating system supported by
that Python version. Git and GitHub provide version control and collaboration.
No pip packages or network connection are needed to execute the program.

## Introduction and topic motivation

Measurement conversion is useful in science, travel, cooking, and computing.
Manual multiplication works for simple scale conversions but becomes harder
when temperature offsets or similarly named gallon definitions are involved.
Explain your own reason for choosing this topic in the submitted report.

The project extends manual conversion with explicit unit definitions, reusable
validation, batch conversion, and saved results. It does not claim to introduce
a new mathematical conversion technique.

## Project concept and procedure

1. Build a registry of units grouped by measurement category.
2. Accept a menu selection, CLI command, or CSV row.
3. Parse a finite floating-point number and resolve unit names.
4. Reject unknown units and incompatible categories.
5. Convert into the category's base unit with a scale and offset.
6. Reject impossible absolute temperatures and numeric overflow.
7. Convert from the base unit into the destination unit.
8. Format the output; optionally store the record or write CSV results.
9. Repeat interactively until the user exits.

```mermaid
flowchart TD
    A[Start and build registry] --> B[Read input]
    B --> C{Valid number and compatible units?}
    C -->|No| D[Explain error]
    C -->|Yes| E[Convert to base unit]
    E --> F{Valid temperature and finite result?}
    F -->|No| D
    F -->|Yes| G[Convert to target and display]
    G --> H[Store session result if requested]
    D --> I{More input?}
    H --> I
    I -->|Yes| B
    I -->|No| J[Exit]
```

## Python concepts and rubric evidence

| Concept | Implementation evidence |
| --- | --- |
| Strings, floats, integers, booleans, None | Inputs, calculations, menu numbering, validation, optional categories |
| Lists | History, unit definitions, batch output, conversion tables |
| Tuples | Unit aliases and CSV result counts |
| Dictionaries | Symbol lookup, menu dispatch, JSON records |
| Sets | Unique categories, aliases, and required CSV columns |
| Loops and conditions | Menu, registration, validation, batch iteration |
| Functions | Parsing, registry creation, batch conversion, CLI entry point |
| Exceptions | ConversionError and input/file error recovery |
| Classes and objects | Unit, Conversion, UnitRegistry, Converter, History, Menu |
| Inheritance | ConversionError derives from ValueError |
| File handling | CSV and JSON import/export using context managers |
| Modules | Standard-library imports and executable main guard |

This covers the topics named in the supplied files; compare against your class
syllabus for any additional topics the instructor expects.

## Challenges and solutions

Temperature needs an offset as well as a factor; both are part of each unit.
US liquid and imperial gallons differ; each receives its own symbol. Binary
and decimal storage prefixes are separate. Invalid CSV rows become error
records so valid rows still finish. Imported history values are recomputed so
stored result fields cannot silently alter the calculations.

Describe which challenges you personally encountered and how you resolved them;
do not present this design discussion as a fabricated development diary.

## Result discussion and evidence

| Input | Expected output or behavior |
| --- | --- |
| 1 mi to km | 1.609344 km |
| 100 C to F | 212 F |
| 1 gal_us to L | 3.785411784 L |
| 1 MiB to byte | 1048576 byte |
| 1 MB to byte | 1000000 byte |
| 1 m to kg | Category error |
| abc m to cm | Numeric input error |
| -1 K to C | Absolute-zero error |
| nan m to cm | Nonfinite input error |

Capture screenshots or a narrated video of these outcomes, the interactive
menu, history save/load, and batch CSV output. The test suite also exercises
every compatible ordered unit pair through a round trip. Attach the actual
test output and discuss the limits of round-trip testing: mutually consistent
factors alone do not prove agreement with an independent reference.

## Conclusion and future improvements

The shared conversion engine supports several interfaces while keeping
validation consistent. Limitations include floating-point rounding, a fixed
unit catalog, no compound expression parser, no currency conversion, and no
graphical interface. Potential extensions include Decimal arithmetic, a GUI,
custom units with validation, and accessible keyboard shortcuts.

## GitHub and appendix

Source and documentation: https://github.com/spencerortyl-prog/Unit-Convert

Keep the repository public until grading finishes. Include the application
source as the code appendix and use the references in README.md. Add genuine
team contribution records and your institution's required AI attribution.

The supplied rubric also requires a PowerPoint and narrated execution recording.
These remain separate submission artifacts. Verify all submission details with
the instructor, including the stated December 1, 2026, 11:59 PM deadline.
