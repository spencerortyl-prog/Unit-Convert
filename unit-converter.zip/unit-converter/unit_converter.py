"""Student unit converter: interactive, command-line, and CSV interfaces.

Run `python unit_converter.py` for the menu or add --help for commands.
Uses only the Python standard library. Python 3.10 or newer is required.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path


class ConversionError(ValueError):
    """An input cannot be converted safely."""


@dataclass(frozen=True)
class Unit:
    category: str
    symbol: str
    name: str
    factor: float
    offset: float = 0.0
    aliases: tuple[str, ...] = ()

    def to_base(self, value: float) -> float:
        return value * self.factor + self.offset

    def from_base(self, value: float) -> float:
        return (value - self.offset) / self.factor


@dataclass(frozen=True)
class Conversion:
    timestamp: str
    category: str
    value: float
    source: str
    target: str
    result: float

    def describe(self, precision: int = 10) -> str:
        left = format(self.value, f'.{precision}g')
        right = format(self.result, f'.{precision}g')
        return f'{left} {self.source} = {right} {self.target}'


class UnitRegistry:
    """Store unit objects and resolve symbols or friendly names."""

    def __init__(self) -> None:
        self.units: dict[str, Unit] = {}
        self.lookup: dict[str, str] = {}

    def add(self, unit: Unit) -> None:
        if unit.factor <= 0 or not math.isfinite(unit.factor):
            raise ValueError('Unit factors must be positive and finite.')
        if not math.isfinite(unit.offset):
            raise ValueError('Unit offsets must be finite.')
        if unit.symbol in self.units:
            raise ValueError(f'Duplicate unit: {unit.symbol}')
        names = (unit.symbol, unit.name, *unit.aliases)
        keys = {name.strip().casefold() for name in names}
        if any(key in self.lookup for key in keys):
            raise ValueError(f'Conflicting unit alias: {unit.symbol}')
        self.units[unit.symbol] = unit
        for key in keys:
            self.lookup[key] = unit.symbol

    def resolve(self, text: str) -> Unit:
        key = text.strip().casefold()
        symbol = self.lookup.get(key)
        if symbol is None:
            raise ConversionError(f'Unknown unit: {text!r}. Use the units command.')
        return self.units[symbol]

    def categories(self) -> list[str]:
        return sorted({unit.category for unit in self.units.values()})

    def in_category(self, category: str) -> list[Unit]:
        return sorted(
            (unit for unit in self.units.values() if unit.category == category),
            key=lambda unit: unit.name,
        )

    def search(self, query: str) -> list[Unit]:
        needle = query.strip().casefold()
        return [
            unit for unit in self.units.values()
            if any(needle in text.casefold()
                   for text in (unit.symbol, unit.name, *unit.aliases))
        ]


def build_registry() -> UnitRegistry:
    registry = UnitRegistry()
    # Each multiplicative category has one consistent base unit.
    definitions = [
        Unit('length', 'm', 'meter', 1, aliases=('meters', 'metre')),
        Unit('length', 'km', 'kilometer', 1000, aliases=('kilometers',)),
        Unit('length', 'cm', 'centimeter', 0.01),
        Unit('length', 'mm', 'millimeter', 0.001),
        Unit('length', 'um', 'micrometer', 0.000001),
        Unit('length', 'in', 'inch', 0.0254, aliases=('inches',)),
        Unit('length', 'ft', 'foot', 0.3048, aliases=('feet',)),
        Unit('length', 'yd', 'yard', 0.9144),
        Unit('length', 'mi', 'mile', 1609.344),
        Unit('length', 'nmi', 'nautical mile', 1852),
        Unit('mass', 'kg', 'kilogram', 1),
        Unit('mass', 'g', 'gram', 0.001),
        Unit('mass', 'mg', 'milligram', 0.000001),
        Unit('mass', 't', 'metric tonne', 1000),
        Unit('mass', 'lb', 'pound', 0.45359237, aliases=('lbs',)),
        Unit('mass', 'oz', 'ounce', 0.028349523125),
        Unit('mass', 'st', 'stone', 6.35029318),
        Unit('time', 's', 'second', 1, aliases=('seconds', 'sec')),
        Unit('time', 'ms', 'millisecond', 0.001),
        Unit('time', 'min', 'minute', 60),
        Unit('time', 'h', 'hour', 3600, aliases=('hr',)),
        Unit('time', 'd', 'day', 86400),
        Unit('time', 'wk', 'week', 604800),
        Unit('area', 'm2', 'square meter', 1),
        Unit('area', 'km2', 'square kilometer', 1000000),
        Unit('area', 'cm2', 'square centimeter', 0.0001),
        Unit('area', 'ft2', 'square foot', 0.09290304),
        Unit('area', 'in2', 'square inch', 0.00064516),
        Unit('area', 'ha', 'hectare', 10000),
        Unit('area', 'acre', 'acre', 4046.8564224),
        Unit('volume', 'L', 'liter', 1, aliases=('litre',)),
        Unit('volume', 'mL', 'milliliter', 0.001),
        Unit('volume', 'm3', 'cubic meter', 1000),
        Unit('volume', 'gal_us', 'US liquid gallon', 3.785411784),
        Unit('volume', 'gal_imp', 'imperial gallon', 4.54609),
        Unit('volume', 'qt_us', 'US liquid quart', 0.946352946),
        Unit('volume', 'pt_us', 'US liquid pint', 0.473176473),
        Unit('volume', 'floz_us', 'US fluid ounce', 0.0295735295625),
        Unit('speed', 'm/s', 'meter per second', 1),
        Unit('speed', 'km/h', 'kilometer per hour', 1 / 3.6, aliases=('kph',)),
        Unit('speed', 'mph', 'mile per hour', 0.44704),
        Unit('speed', 'ft/s', 'foot per second', 0.3048),
        Unit('speed', 'kn', 'knot', 1852 / 3600),
        Unit('temperature', 'K', 'kelvin', 1),
        Unit('temperature', 'C', 'celsius', 1, 273.15, ('degc',)),
        Unit('temperature', 'F', 'fahrenheit', 5 / 9, 273.15 - 32 * 5 / 9, ('degf',)),
        Unit('temperature', 'R', 'rankine', 5 / 9),
        Unit('energy', 'J', 'joule', 1),
        Unit('energy', 'kJ', 'kilojoule', 1000),
        Unit('energy', 'Wh', 'watt hour', 3600),
        Unit('energy', 'kWh', 'kilowatt hour', 3600000),
        Unit('energy', 'cal', 'thermochemical calorie', 4.184),
        Unit('energy', 'kcal', 'thermochemical kilocalorie', 4184),
        Unit('pressure', 'Pa', 'pascal', 1),
        Unit('pressure', 'kPa', 'kilopascal', 1000),
        Unit('pressure', 'bar', 'bar', 100000),
        Unit('pressure', 'atm', 'standard atmosphere', 101325),
        Unit('pressure', 'psi', 'pound per square inch', 6894.757293168),
        Unit('pressure', 'Torr', 'torr', 101325 / 760),
        Unit('data', 'byte', 'byte', 1, aliases=('bytes',)),
        Unit('data', 'bit', 'bit', 0.125, aliases=('bits',)),
        Unit('data', 'kB', 'kilobyte', 1000),
        Unit('data', 'MB', 'megabyte', 1000000),
        Unit('data', 'GB', 'gigabyte', 1000000000),
        Unit('data', 'KiB', 'kibibyte', 1024),
        Unit('data', 'MiB', 'mebibyte', 1048576),
        Unit('data', 'GiB', 'gibibyte', 1073741824),
    ]
    for unit in definitions:
        registry.add(unit)
    return registry


def parse_number(text: str | float) -> float:
    try:
        value = float(text)
    except (ValueError, TypeError, OverflowError) as error:
        raise ConversionError('Enter a number, such as 12.5 or 1e3.') from error
    if not math.isfinite(value):
        raise ConversionError('NaN and infinity are not supported.')
    return value


class Converter:
    def __init__(self, registry: UnitRegistry) -> None:
        self.registry = registry

    def convert(self, value: str | float, source: str, target: str) -> Conversion:
        number = parse_number(value)
        source_unit = self.registry.resolve(source)
        target_unit = self.registry.resolve(target)
        if source_unit.category != target_unit.category:
            raise ConversionError('Source and target must belong to the same category.')
        base_value = source_unit.to_base(number)
        if not math.isfinite(base_value):
            raise ConversionError('Value is too large for this conversion.')
        if source_unit.category == 'temperature' and base_value < -1e-10:
            raise ConversionError('Temperature cannot be below absolute zero.')
        if source_unit.category == 'temperature':
            base_value = max(0.0, base_value)
        result = target_unit.from_base(base_value)
        if not math.isfinite(result):
            raise ConversionError('Result exceeds the supported numeric range.')
        return Conversion(
            datetime.now(timezone.utc).isoformat(timespec='seconds'),
            source_unit.category,
            number,
            source_unit.symbol,
            target_unit.symbol,
            result,
        )

    def table(self, value: str | float, source: str) -> list[Conversion]:
        unit = self.registry.resolve(source)
        return [self.convert(value, source, target.symbol)
                for target in self.registry.in_category(unit.category)]


class History:
    """Keep session results; import and export explicit JSON files."""

    def __init__(self) -> None:
        self.records: list[Conversion] = []

    def add(self, record: Conversion) -> None:
        self.records.append(record)

    def clear(self) -> None:
        self.records.clear()

    def save(self, path: Path) -> None:
        payload = [asdict(record) for record in self.records]
        path.write_text(json.dumps(payload, indent=2, allow_nan=False), encoding='utf-8')

    def load(self, path: Path, converter: Converter) -> None:
        payload = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(payload, list):
            raise ConversionError('History must contain a JSON list.')
        restored = []
        for item in payload:
            if not isinstance(item, dict):
                raise ConversionError('Each history item must be an object.')
            try:
                # Recompute rather than trusting stored results or categories.
                record = converter.convert(item['value'], item['source'], item['target'])
            except (KeyError, TypeError, AttributeError) as error:
                raise ConversionError('A history item has missing or invalid fields.') from error
            restored.append(record)
        self.records = restored


def print_units(registry: UnitRegistry, category: str | None = None) -> None:
    categories = registry.categories()
    if category is not None:
        category = category.casefold()
        if category not in categories:
            raise ConversionError(f'Unknown category. Choose: {", ".join(categories)}')
        categories = [category]
    for name in categories:
        print(f'\n{name.upper()}')
        for unit in registry.in_category(name):
            print(f'  {unit.symbol:<10} {unit.name}')


def batch_convert(converter: Converter, source: Path, destination: Path) -> tuple[int, int]:
    if source.resolve() == destination.resolve():
        raise ConversionError('Input and output CSV paths must be different.')
    rows = []
    successful = 0
    failed = 0
    with source.open(newline='', encoding='utf-8-sig') as handle:
        reader = csv.DictReader(handle)
        required = {'value', 'source', 'target'}
        if not required.issubset(reader.fieldnames or []):
            raise ConversionError('CSV needs value,source,target columns.')
        for row in reader:
            output = {key: row.get(key, '') for key in ('value', 'source', 'target')}
            try:
                if any(output[key] is None for key in output):
                    raise ConversionError('CSV row has missing values.')
                record = converter.convert(output['value'], output['source'], output['target'])
                output.update(result=record.result, status='ok', error='')
                successful += 1
            except ConversionError as error:
                output.update(result='', status='error', error=str(error))
                failed += 1
            rows.append(output)
    with destination.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(
            handle, fieldnames=('value', 'source', 'target', 'result', 'status', 'error')
        )
        writer.writeheader()
        writer.writerows(rows)
    return successful, failed


class Menu:
    def __init__(self, converter: Converter) -> None:
        self.converter = converter
        self.history = History()
        self.precision = 10
        self.actions = {
            '1': self.convert_one,
            '2': self.show_units,
            '3': self.show_table,
            '4': self.show_history,
            '5': self.save_history,
            '6': self.load_history,
            '7': self.batch,
            '8': self.search,
            '9': self.set_precision,
            '10': self.clear_history,
            '11': self.help,
        }

    def run(self) -> None:
        print('UNIT CONVERTER | Python project')
        while True:
            print('\n1 Convert       2 Units          3 Conversion table')
            print('4 History       5 Save history   6 Load history')
            print('7 CSV batch     8 Search units   9 Display precision')
            print('10 Clear history  11 Help         0 Exit')
            try:
                choice = input('Choose: ').strip()
                if choice == '0':
                    print('Goodbye!')
                    return
                action = self.actions.get(choice)
                if action is None:
                    print('Choose one of the numbered options.')
                    continue
                action()
            except (ConversionError, OSError, ValueError, csv.Error) as error:
                print(f'Error: {error}')
            except (EOFError, KeyboardInterrupt):
                print('\nGoodbye!')
                return

    def convert_one(self) -> None:
        value = input('Value: ')
        source = input('From unit: ')
        target = input('To unit: ')
        result = self.converter.convert(value, source, target)
        self.history.add(result)
        print(result.describe(self.precision))

    def show_units(self) -> None:
        category = input('Category (Enter for all): ').strip()
        print_units(self.converter.registry, category or None)

    def show_table(self) -> None:
        value = input('Value: ')
        source = input('From unit: ')
        for record in self.converter.table(value, source):
            print(record.describe(self.precision))

    def show_history(self) -> None:
        if not self.history.records:
            print('No saved conversions in this session.')
            return
        for index, record in enumerate(self.history.records, start=1):
            print(f'{index}. {record.describe(self.precision)}')

    def save_history(self) -> None:
        path = Path(input('JSON file to save: ').strip())
        if path.exists():
            if input('File exists. Overwrite? [y/N]: ').strip().lower() != 'y':
                return
        self.history.save(path)
        print(f'Saved {len(self.history.records)} conversion(s).')

    def load_history(self) -> None:
        path = Path(input('JSON file to load (replaces session history): ').strip())
        self.history.load(path, self.converter)
        print(f'Loaded {len(self.history.records)} conversion(s).')

    def batch(self) -> None:
        source = Path(input('Input CSV: ').strip())
        target = Path(input('Output CSV: ').strip())
        if target.exists():
            if input('File exists. Overwrite? [y/N]: ').strip().lower() != 'y':
                return
        passed, failed = batch_convert(self.converter, source, target)
        print(f'{passed} succeeded; {failed} failed. See {target}.')

    def search(self) -> None:
        matches = self.converter.registry.search(input('Search text: '))
        if not matches:
            print('No matching units.')
        for unit in matches:
            print(f'{unit.symbol:<10} {unit.name} ({unit.category})')

    def set_precision(self) -> None:
        precision = int(input('Significant digits (1-15): '))
        if not 1 <= precision <= 15:
            raise ConversionError('Precision must be between 1 and 15.')
        self.precision = precision
        print('Display precision updated; calculations retain full float precision.')

    def clear_history(self) -> None:
        if input('Clear session history? [y/N]: ').strip().lower() == 'y':
            self.history.clear()
            print('Session history cleared.')

    def help(self) -> None:
        print('Enter symbols or full names. Unit lookup ignores capitalization.')
        print('Use byte or bit explicitly; single-letter B and b are unsupported.')
        print('Temperature uses offsets; temperatures below absolute zero are rejected.')
        print('US liquid and imperial volume units have separate names.')
        print('Data: kB/MB/GB use powers of 1000; KiB/MiB/GiB use powers of 1024.')
        print('Scientific notation is accepted. Do not include commas in numbers.')
        print('History stays in memory until you explicitly save it.')


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description='Convert physical units offline.')
    commands = parser.add_subparsers(dest='command')
    convert = commands.add_parser('convert', help='Convert one value')
    convert.add_argument('value')
    convert.add_argument('source')
    convert.add_argument('target')
    convert.add_argument('--precision', type=int, choices=range(1, 16), default=10)
    units = commands.add_parser('units', help='List supported units')
    units.add_argument('category', nargs='?')
    table = commands.add_parser('table', help='Convert to every compatible unit')
    table.add_argument('value')
    table.add_argument('source')
    batch = commands.add_parser('batch', help='Convert a CSV file')
    batch.add_argument('input', type=Path)
    batch.add_argument('output', type=Path)
    batch.add_argument('--overwrite', action='store_true')
    search = commands.add_parser('search', help='Find units by name')
    search.add_argument('query')
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    converter = Converter(build_registry())
    try:
        if args.command is None:
            Menu(converter).run()
        elif args.command == 'convert':
            result = converter.convert(args.value, args.source, args.target)
            print(result.describe(args.precision))
        elif args.command == 'units':
            print_units(converter.registry, args.category)
        elif args.command == 'table':
            for record in converter.table(args.value, args.source):
                print(record.describe())
        elif args.command == 'search':
            for unit in converter.registry.search(args.query):
                print(f'{unit.symbol}: {unit.name} ({unit.category})')
        elif args.command == 'batch':
            if args.output.exists() and not args.overwrite:
                raise ConversionError('Output exists; use --overwrite to replace it.')
            passed, failed = batch_convert(converter, args.input, args.output)
            print(f'{passed} succeeded; {failed} failed.')
            return 1 if failed else 0
    except (ConversionError, OSError, ValueError, csv.Error) as error:
        print(f'Error: {error}', file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
